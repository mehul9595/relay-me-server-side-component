Business and Advertising Agency Icon Set
========================================

Designer: Pixel Icons (https://www.iconfinder.com/azisher)
